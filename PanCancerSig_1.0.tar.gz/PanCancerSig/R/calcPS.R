#' PanCancer Prognostic Score Calculation Function
#'
#' This function calculates prognostic score for a cancer type.
#' @param geneExp A gene expression matrix.
#' @param outFile path_to_output/filename.
#' @param canType Abbreviation of TCGA cancer. If set to "All", all signatures will be used.
#' @param platform Microarray or RNA-seq? Defaults as "array". If RNA-seq, set it to "RNAseq".
#' @keywords Prognostic score calculation
#' @export 
#' @examples
#' calcPS()

calcPS <- function(geneExp, outFile, canType, platform = "array"){
	
	myExpr <- geneExp
	myOut <- outFile
	myCan <- canType
	myPlat <- platform
	
	mydat <- myExpr
	
	myinf <- system.file("extdata", "TCGA_PanCan_ProgSig_4BASE.txt", package = "PanCancerSig")
	mywt <- read.table(myinf, sep = "\t", header = T, row.names = 1)
	
	if(myCan != "All"){
		ind <- grep(myCan, colnames(mywt))
		mywt <- mywt[, ind]
	}else{
		print("All cancer types are selected! The calculation will be slow...")
	}
	
	source(system.file("extdata", "base5.R", package = "PanCancerSig"))
	print("Calculating PS scores...")
	
	if(myPlat == "RNAseq"){
		mydat <- log10(mydat * 1000 + 1)
		xx <- base5(mydat, mywt, perm = 1000, myOut, median.norm = T)
	}else{
		posv <- sum(mydat)
		negv <- sum(mydat < 0)
		if((posv/negv) > 6){
			xx <- base5(mydat, mywt, perm = 1000, myOut, median.norm = T)
		}else{
			xx <- base5(mydat, mywt, perm = 1000, myOut, median.norm = F)	
		}
	}
}
