#' Concordance Score calculation Function
#'
#' This function calculates concordance score.
#' @param psFile path_to_calPSscore_output/filename.
#' @param clinicalInfo A clinical information matrix in the format sample_ID, time_to_death, event(binary), stage(number), grade(number), age
#' @param psCut The cutoff of ps score for 2 groups. Defaults as median. It can be set as "median", "mean" or a number.
#' @param saveOut Whether save the output as a text file. Defaults as FALSE.
#' @param outFile Set to path_to_survivalAnalysis_output/filename if saveOut is TRUE. Defaults as "".
#' @keywords Survival analysis
#' @export 
#' @examples
#' survAnalysis()

survAnalysis <- function(psFile, clinicalInfo, psCut = "median", saveOut = FALSE, outFile = ""){
	
	myPS <- psFile
	myCli <- clinicalInfo
	myOut <- outFile
	
	#--
	mydat <- read.table(myPS, sep="\t", header=T, row.names=1)
	#here 2 need to change with the PS scores files
	if(ncol(mydat) > 4){
		cnum <- ncol(mydat) / 4
		mydat <- mydat[, 1:cnum] - mydat[, (cnum+1):(cnum*2)]
		colnames(mydat) <- gsub("_up.ES", "", colnames(mydat))
	}else{
		col_name <- gsub("_up.ES", "", colnames(mydat)[1])
		row_name <- row.names(mydat)
		mydat <- as.data.frame(mydat[, 1] - mydat[, 2])
		colnames(mydat) <- col_name
		row.names(mydat) <- row_name
	}
	
	#--
	info <- myCli
	# here we need to ask users to prepare their clinical information in the format 
	# sample_ID, time_to_death, event(binary), stage(number), grade(number), age 
	
	t.surv <- as.numeric(info[, "time_to_death"])
	e.surv <- as.numeric(info[, "event"])
	info <- cbind(t.surv, e.surv, info)

	comxx <- intersect(row.names(mydat), row.names(info))
	mydat <- mydat[comxx, , drop = FALSE]
	info <- info[comxx,]
	
	if(!("survival" %in% rownames(installed.packages()))){
		print ("Installation of 'survival' R package...")
 		install.packages("survival")
    }
	library("survival")

	survreg.pval <- coxph_b.pval <- coxph_c.pval <- rep(0, ncol(mydat))
	coxph_b.hr <- coxph_c.hr <- rep(0, ncol(mydat))
	coxph_b.cs <- coxph_c.cs <- rep(0, ncol(mydat))
	
	for(k in 1:ncol(mydat)){
		mytf <- as.numeric(mydat[, k])
		if(psCut == "median"){
			mytag <- ifelse(mytf > median(mytf), 1, 0)
		}else if(psCut == "mean"){
			mytag <- ifelse(mytf > mean(mytf), 1, 0)
		}else{
			mycut <- as.numeric(psCut)
			mytag <- rep(-1, length(mytf))
			tag <- which(mytf > mycut)
			mytag[tag] <- 1
			tag <- which(mytf < mycut * (-1))
			mytag[tag] <- 0
		}
		xx <- cbind(mytf, mytag, info)
		xx <- subset(xx, mytag >= 0)
		xx <- xx[xx[, "t.surv"] > 0,]
		
		mycox <- coxph(Surv(t.surv, e.surv)~mytag, xx) 
		mycox <- summary(mycox)
		coxph_b.pval[k] <- mycox$coefficients[5]
		tmp <- mycox$conf.int
		coxph_b.hr[k] <- tmp[1]
		coxph_b.cs[k] <- mycox$concordance[1]

		mycox <- coxph(Surv(t.surv, e.surv)~mytf, xx) 
		mycox <- summary(mycox)
		coxph_c.pval[k] <- mycox$coefficients[5]
		tmp <- mycox$conf.int
		coxph_c.hr[k] <- tmp[1]
		coxph_c.cs[k] <- mycox$concordance[1]
	}
	coxph_b.qval <- p.adjust(coxph_b.pval, "BH")
	coxph_c.qval <- p.adjust(coxph_c.pval, "BH")

	name <- colnames(mydat)
	res <- data.frame(name, coxph_b.pval, coxph_b.qval, coxph_b.hr, coxph_b.cs, coxph_c.pval, coxph_c.qval, coxph_c.hr, coxph_c.cs)
	colnames(res) <- c("sample_ID", "Coxph_B_Pval", "Coxph_B_FDR", "Coxph_B_HR", "Coxph_B_Concordance", "Coxph_C_Pval", "Coxph_C_FDR", "Coxph_C_HR", "Coxph_C_Concordance")
	return(res)
	if(saveOut == T){
		write.table(res, myOut, sep = "\t", row.names = F, quote = F, col.names = T)
	}
}
